package com.capgemini.GeodeTest;

import java.util.Map;

import org.apache.geode.cache.Region;
import org.apache.geode.cache.client.*;
import org.apache.geode.compression.Compressor;
import org.apache.geode.compression.SnappyCompressor;

public class App {
	public static void main(String[] args) throws Exception {
		ClientCache cache = new ClientCacheFactory().addPoolLocator(
				" LIN65000371", 59894).create();
		Region<String, String> region = cache
				.<String, String> createClientRegionFactory(
						ClientRegionShortcut.CACHING_PROXY).create("region1");
		
		Region myRegion = cache.getRegion("region1");
		Compressor compressor = myRegion.getAttributes().getCompressor();
		System.out.println(myRegion + "........." + compressor);
		region.put("1", "Hello");
		region.put("2", "World");

		for (Map.Entry<String, String> entry : region.entrySet()) {
			System.out.format("key = %s, value = %s\n", entry.getKey(),
					entry.getValue());
		}
		cache.close();
	}
}